#ifndef IMPORTS_H
#define IMPORTS_H

//Contém todas as bibliotecas usadas neste trabalho

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <sys/types.h>
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h>
#include <time.h>
#include <sys/msg.h>

#endif 