#ifndef SEMAPHORE_H
#define SEMAPHORE_H

#define VALOR_INICIAL_SEMAFORO 1

#include "imports.h"

void create_semaphore(sem_t **semaforo);

#endif